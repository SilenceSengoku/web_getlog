document.addEventListener("DOMContentLoaded", function() {
    var timeInput = document.getElementById("time");
    var currentTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    timeInput.value = currentTime;
});
