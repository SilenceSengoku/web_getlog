from flask import Flask, render_template, request  
  
app = Flask(__name__)  
  
@app.route('/', methods=['GET', 'POST'])  
def index():  
    if request.method == 'POST':  
        selected_items = request.form.getlist('items[]')  
        return render_template('result.html', selected_items=selected_items)  
    else:  
        return render_template('index.html')  
  
if __name__ == '__main__':  
    app.run(debug=True)
