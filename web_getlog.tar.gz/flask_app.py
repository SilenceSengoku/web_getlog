from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)

# 配置 MySQL 数据库连接
db = mysql.connector.connect(
    host="127.0.0.1",
    user="flying_squirrel",
    password="3enO2#X3RvHD",
    database="ods"
)

# 创建数据库游标
cursor = db.cursor()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # 获取前端提交的数据
        time_hhmm = request.form["time_hhmm"]
        act_class = request.form["act_class"]
        act_details = request.form["act_details"]

        # 将数据存储到数据库
        insert_query = "INSERT INTO ods_time_weblog_detail_s_d (time_hhmm, act_class, act_details) VALUES (%s, %s ,%s)"
        cursor.execute(insert_query, (time_hhmm, act_class ,act_details))
        db.commit()
    #image_path = "/home/sengoku/aboutwork/mulberry1/get_self_message/web_getlog/templates/images/bj1.png"
    #return render_template("index.html", image_path=image_path)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
    
